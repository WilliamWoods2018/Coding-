package com.example.mainActivity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class About_us extends AppCompatActivity {
    Button home, toFeedback;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        toFeedback = (Button)findViewById(R.id.Feedbackbutton);
        home = (Button)findViewById(R.id.button8);
        toFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openForum();
            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHomeScreen();
            }
        });
    }

    private void openForum() {
        Intent feed = new Intent(this, feedbackForum.class);
        startActivity(feed);
    }

    private void openHomeScreen() {
        Intent home = new Intent(this, MainScreen.class);
        startActivity(home);
    }
}
