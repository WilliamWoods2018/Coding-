package com.example.mainActivity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class create_an_event extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Button home;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_an_event);

        Spinner spinner1 = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adpater = ArrayAdapter.createFromResource(this, R.array.options, android.R.layout.simple_spinner_item);
        adpater.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adpater);
        spinner1.setOnItemSelectedListener(this);
        home = (Button)findViewById(R.id.button6);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHomeScreen();
            }
        });
    }

    private void openHomeScreen() {
        Intent home = new Intent(this, MainScreen.class);
        startActivity(home);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
