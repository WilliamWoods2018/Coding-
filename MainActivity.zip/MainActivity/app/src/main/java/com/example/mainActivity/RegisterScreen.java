package com.example.mainActivity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterScreen extends AppCompatActivity {
    PickupDatabase db;
    EditText e1, e2, e3, e4;
    Button b1, b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new PickupDatabase(this);
        setContentView(R.layout.activity_register);
        e1=(EditText)findViewById(R.id.usernameInput);
        e2=(EditText)findViewById(R.id.passInput);
        e3=(EditText)findViewById(R.id.confirmPassInput);
        e4=(EditText)findViewById(R.id.emailInput);
        b2=(Button)findViewById(R.id.toLogin);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLoginScreen();

            }
        });


        b1 = (Button)findViewById(R.id.registerButton);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = e1.getText().toString();
                String s2 = e2.getText().toString();
                String s3 = e3.getText().toString();
                String s4 = e4.getText().toString();
                String domainName = s4.substring(s4.indexOf('@')+1, s4.length());
                if (s1.equals("")||s2.equals("")||s3.equals("")||s4.equals("")){
                    Toast.makeText(getApplicationContext(), "Error: Fields are empty", Toast.LENGTH_SHORT).show();
                }
                else{
                    if(s2.equals(s3) && domainName.equals("ilstu.edu")){
                        Boolean checkmail = db.checkEmail(s4);
                        if(checkmail==true){
                            Boolean insert = db.insert(s1,s4,s2);
                            if(insert == true){
                                Toast.makeText(getApplicationContext(),"Register Complete", Toast.LENGTH_SHORT).show();
                                openLoginScreen();
                            }
                        }
                        else{
                            Toast.makeText(getApplicationContext(),"Email Already In Use",Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Password Does Not Match", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void openLoginScreen() {
        Intent goLoginPage = new Intent(this, LoginActivity.class);
        startActivity(goLoginPage);
    }
}
