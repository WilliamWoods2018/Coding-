package com.example.mainActivity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

public class MainScreen extends AppCompatActivity {
    Button b1, b2, b3, b4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);
        b1 = findViewById(R.id.createEvent);
        b2 = findViewById(R.id.viewEvents);
        b3 = findViewById(R.id.aboutPage);
        b4 = findViewById(R.id.exitButton);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goCreateEventPage();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goViewEventsPage();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goAboutPage();
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    private void goCreateEventPage() {
        Intent CreateEvent = new Intent(this, create_an_event.class);
        startActivity(CreateEvent);
    }
    private void goViewEventsPage() {
        Intent ViewEvents = new Intent(this, eventListing.class);
        startActivity(ViewEvents);
    }
    private void goAboutPage(){
        Intent AboutPage = new Intent(this, About_us.class);
        startActivity(AboutPage);
    }
}
